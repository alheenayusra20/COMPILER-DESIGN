/*
Experiment 8: Symbol table (linear)
Commands:
    insert <name> <type>
    find <name>
    print
    quit
*/
#include <stdio.h>
#include <string.h>
#define MAX 256
struct Sym{ char name[64]; char type[32]; } st[MAX]; int n=0;
int main(void){
    char cmd[16], a[64], b[32];
    while(printf("> "), fflush(stdout), scanf("%15s", cmd)==1){
        if(!strcmp(cmd,"insert")){
            scanf("%63s %31s", a, b);
            strcpy(st[n].name,a); strcpy(st[n].type,b); n++;
            puts("OK");
        }else if(!strcmp(cmd,"find")){
            scanf("%63s", a); int f=0;
            for(int i=0;i<n;i++) if(!strcmp(st[i].name,a)){ printf("%s : %s\n", st[i].name, st[i].type); f=1; break; }
            if(!f) puts("NOT_FOUND");
        }else if(!strcmp(cmd,"print")){
            for(int i=0;i<n;i++) printf("%d) %s : %s\n", i+1, st[i].name, st[i].type);
        }else if(!strcmp(cmd,"quit")) break;
        else puts("UNKNOWN");
    }
    return 0;
}
