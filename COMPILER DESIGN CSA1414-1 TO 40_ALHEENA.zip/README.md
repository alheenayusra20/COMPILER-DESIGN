# CSA14 — List of Experiments — Reference Solutions

This folder contains **40** small programs (C and Lex/Flex) matching the experiments listed in your PDF.  
Each source file starts with a short **Sample Input/Output** in comments. Build and test locally with GCC and Flex.

## Build (Linux/macOS)
```bash
# C programs
gcc 01_lex_analyzer_basic.c -o p01
./p01 < sample.c

# Lex programs (requires flex)
flex 27_tokenize_c.l && gcc lex.yy.c -o p27 && ./p27 < sample.c
```

> Note: The Lex examples are intentionally minimal and educational. You can refine patterns, add full token sets, and integrate with parser generators as needed.
