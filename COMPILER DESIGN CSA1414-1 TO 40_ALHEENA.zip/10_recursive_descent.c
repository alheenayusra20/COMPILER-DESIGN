/*
Experiment 10: Recursive Descent Parser for simple expressions with ids and digits.
Sample Input: (a+b)*c
Output: PARSE_OK
*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
const char* s; int i;
int E(), T(), F();
int accept(char c){ if(s[i]==c){ i++; return 1;} return 0; }
int id(){ if(isalpha(s[i])||isdigit(s[i])){ while(isalnum(s[i])) i++; return 1; } return 0; }
int F(){ if(accept('(')){ if(!E()||!accept(')')) return 0; return 1; } return id(); }
int T(){ if(!F()) return 0; while(s[i]=='*'||s[i]=='/'){ i++; if(!F()) return 0; } return 1; }
int E(){ if(!T()) return 0; while(s[i]=='+'||s[i]=='-'){ i++; if(!T()) return 0; } return 1; }
int main(void){
    static char buf[1024]; if(!fgets(buf,sizeof(buf),stdin)) return 0; s=buf; i=0;
    puts(E() && s[i]=='\n' ? "PARSE_OK" : "PARSE_FAIL");
    return 0;
}
