/*
Experiment 4: Count whitespaces and newlines
Input: "a b\nc\t d"
Output: spaces=2 tabs=1 newlines=1
*/
#include <stdio.h>
int main(void){
    int c, spaces=0, tabs=0, nls=0;
    while((c=getchar())!=EOF){
        if(c==' ') spaces++;
        else if(c=='\t') tabs++;
        else if(c=='\n') nls++;
    }
    printf("spaces=%d tabs=%d newlines=%d\n", spaces, tabs, nls);
    return 0;
}
