/*
Experiment 9: Check if string satisfies a grammar (example: balanced parentheses)
Input: (()())
Output: ACCEPT
*/
#include <stdio.h>
int main(void){
    int c, bal=0;
    while((c=getchar())!=EOF && c!='\n'){
        if(c=='(') bal++;
        else if(c==')'){ bal--; if(bal<0){ puts("REJECT"); return 0; } }
    }
    puts(bal==0?"ACCEPT":"REJECT");
    return 0;
}
