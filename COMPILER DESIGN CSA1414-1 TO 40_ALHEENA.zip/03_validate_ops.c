/*
Experiment 3: Recognize + - * / operators
Input: a + b - c * d / e
Output: OP(+) OP(-) OP(*) OP(/)
*/
#include <stdio.h>
int main(void){
    int c;
    while((c=getchar())!=EOF){
        if(c=='+'||c=='-'||c=='*'||c=='/')
            printf("OP(%c)\n", c);
    }
    return 0;
}
