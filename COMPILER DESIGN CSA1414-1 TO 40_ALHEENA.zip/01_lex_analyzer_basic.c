/*
Experiment 1:
Develop a lexical analyzer to identify identifiers, constants, and operators using C.
Sample Input:
    int x = a1 + 23 * b;
Sample Output:
    IDENT(int) IDENT(x) OP(=) IDENT(a1) OP(+) CONST(23) OP(*) IDENT(b) OP(;) 
*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int isIdentStart(int c){ return isalpha(c) || c=='_'; }
int isIdentChar(int c){ return isalnum(c) || c=='_'; }
int isOp(int c){ return strchr("+-*/%=<>&|!^~;:,(){}[]", c)!=NULL; }

int main(void){
    int c;
    while((c = getchar()) != EOF){
        if(isspace(c)) continue;
        if(isIdentStart(c)){
            char buf[128]; int i=0;
            buf[i++] = c;
            while((c = getchar()) != EOF && isIdentChar(c) && i<127) buf[i++]=c;
            buf[i]=0;
            if(c!=EOF) ungetc(c, stdin);
            if(strcmp(buf,"int")==0||strcmp(buf,"float")==0||strcmp(buf,"char")==0||
               strcmp(buf,"return")==0||strcmp(buf,"if")==0||strcmp(buf,"else")==0){
                printf("KW(%s) ", buf);
            }else{
                printf("IDENT(%s) ", buf);
            }
        }else if(isdigit(c)){
            long val = c - '0';
            while((c = getchar()) != EOF && isdigit(c)) val = val*10 + (c-'0');
            if(c!=EOF) ungetc(c, stdin);
            printf("CONST(%ld) ", val);
        }else if(c=='/' ){
            int d=getchar();
            if(d=='/'){ while((c=getchar())!=EOF && c!='\n'); }
            else if(d=='*'){ int prev=0; while((c=getchar())!=EOF){ if(prev=='*' && c=='/') break; prev=c;} }
            else { ungetc(d, stdin); printf("OP(/) "); }
        }else if(isOp(c)){
            printf("OP(%c) ", c);
        }else{
            printf("UNK(%c) ", c);
        }
    }
    return 0;
}
