/*
Experiment 5: Validate C-style identifier
Input: _abc1
Output: VALID
*/
#include <stdio.h>
#include <ctype.h>
int isStart(int c){ return c=='_'||isalpha(c); }
int isChar(int c){ return c=='_'||isalnum(c); }
int main(void){
    char s[256]; 
    if(scanf("%255s", s)!=1) return 0;
    if(!isStart(s[0])){ puts("INVALID"); return 0; }
    for(int i=1; s[i]; ++i) if(!isChar(s[i])){ puts("INVALID"); return 0; }
    puts("VALID");
    return 0;
}
