/*
Experiment 14: Eliminate common subexpressions in simple 3AC input (a=b+c; d=b+c; -> t=b+c; a=t; d=t;)
Input:
a=b+c;
d=b+c;
e=a+d;
Output:
t1=b+c;
a=t1;
d=t1;
e=a+d;
*/
#include <stdio.h>
#include <string.h>
struct St{ char l[16], a[16], op[4], b[16]; } st[256]; int n=0;
int main(void){
    char line[128];
    while(fgets(line,sizeof(line),stdin)){
        struct St s={0}; if(sscanf(line,"%15[^=]=%15[^+*/-]%3[+*/- ]%15s",s.l,s.a,s.op,s.b)==4){
            // trim
            for(int i=0;s.a[i];++i) if(s.a[i]==' '){ memmove(&s.a[i],&s.a[i+1],strlen(&s.a[i+1])+1); i--; }
            for(int i=0;s.b[i];++i) if(s.b[i]==';'||s.b[i]==' '){ s.b[i]=0; break; }
            int found=-1;
            for(int j=0;j<n;j++) if(!strcmp(st[j].a,s.a)&&!strcmp(st[j].op,s.op)&&!strcmp(st[j].b,s.b)) { found=j; break; }
            if(found==-1){ st[n]=s; n++; printf("t%d=%s%s%s;\n", n, s.a, s.op, s.b); printf("%s=t%d;\n", s.l, n); }
            else{ printf("%s=t%d;\n", s.l, found+1); }
        }else{
            fputs(line, stdout);
        }
    }
    return 0;
}
