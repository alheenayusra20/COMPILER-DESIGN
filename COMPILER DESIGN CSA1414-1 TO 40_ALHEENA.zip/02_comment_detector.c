/*
Experiment 2: Detect if line is a comment (//... or /* ... */)
Sample Inputs:
    // hello
    /* block */
    x = 1;
Sample Outputs:
    COMMENT(SL)
    COMMENT(ML)
    NOT_COMMENT
*/
#include <stdio.h>
#include <string.h>
int main(void){
    char s[1024];
    while(fgets(s,sizeof(s),stdin)){
        if(strncmp(s,"//",2)==0) { puts("COMMENT(SL)"); continue; }
        if(strncmp(s,"/*",2)==0){
            char *p = strstr(s,"*/");
            if(p) puts("COMMENT(ML)");
            else puts("POSSIBLE_ML_START");
            continue;
        }
        puts("NOT_COMMENT");
    }
    return 0;
}
