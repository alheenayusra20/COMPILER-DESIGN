/*
Experiment 13: Count characters, words, lines
Input: Hello world\nLine2
Output: chars=?, words=3, lines=2
*/
#include <stdio.h>
#include <ctype.h>
int main(void){
    int c, chars=0, words=0, lines=0, in=0;
    while((c=getchar())!=EOF){
        chars++;
        if(c=='\n') lines++;
        if(isspace(c)) in=0; else if(!in){ in=1; words++; }
    }
    printf("chars=%d words=%d lines=%d\n", chars, words, lines);
    return 0;
}
