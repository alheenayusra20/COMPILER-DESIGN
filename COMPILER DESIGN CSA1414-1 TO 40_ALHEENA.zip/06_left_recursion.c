/*
Experiment 6: Eliminate immediate left recursion for A->Aα1|...|Aαm|β1|...|βn
Input:
A->Aa|b|Ac|d
Output:
A->bA'|dA'
A'->aA'|cA'|ε
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(void){
    char line[1024];
    if(!fgets(line,sizeof(line),stdin)) return 0;
    char lhs, *rhs = strchr(line,'>'); 
    if(!rhs){ puts("Invalid"); return 0; }
    lhs = line[0]; rhs+=1;
    // split by |
    char *alts[128]; int na=0;
    char *tok = strtok(rhs, "|\n\r");
    while(tok && na<128){ while(*tok==' ') tok++; alts[na++]=tok; tok=strtok(NULL,"|\n\r"); }
    char* alpha[128]; int na_alpha=0;
    char* beta[128]; int na_beta=0;
    for(int i=0;i<na;i++){
        if(alts[i][0]==lhs) alpha[na_alpha++]=alts[i]+1;
        else beta[na_beta++]=alts[i];
    }
    if(na_alpha==0){ printf("%c->", lhs); for(int i=0;i<na;i++){ if(i) printf("|"); printf("%s", alts[i]); } printf("\n"); return 0; }
    printf("%c->", lhs);
    for(int i=0;i<na_beta;i++){ if(i) printf("|"); printf("%s%c'", beta[i], lhs); }
    printf("\n%c'->", lhs);
    for(int i=0;i<na_alpha;i++){ if(i) printf("|"); printf("%s%c'", alpha[i], lhs); }
    printf("|ε\n");
    return 0;
}
