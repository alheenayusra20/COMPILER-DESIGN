/*
Experiment 15: Backend codegen from simple 3AC (x=a+b) to stack machine.
Input:
t1=b*c
t2=a+t1
Output:
LOAD b
LOAD c
MUL
STORE t1
LOAD a
LOAD t1
ADD
STORE t2
*/
#include <stdio.h>
#include <string.h>
int main(void){
    char l[16], a[16], op[4], b[16];
    while(scanf("%15[^=]=%15[^+*/-]%3[+*/- ]%15s", l,a,op,b)==4){
        for(int i=0;a[i];++i) if(a[i]==' ') memmove(&a[i],&a[i+1],strlen(&a[i+1])+1), i--;
        for(int i=0;b[i];++i) if(b[i]==';'||b[i]==' ') { b[i]=0; break; }
        printf("LOAD %s\nLOAD %s\n", a, b);
        if(op[0]=='+') puts("ADD");
        else if(op[0]=='-') puts("SUB");
        else if(op[0]=='*') puts("MUL");
        else if(op[0]=='/') puts("DIV");
        printf("STORE %s\n", l);
    }
    return 0;
}
