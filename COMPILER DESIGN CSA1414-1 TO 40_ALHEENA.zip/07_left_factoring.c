/*
Experiment 7: Left factoring single production with two alternatives
Input: A->ab|ac
Output:
A->aA'
A'->b|c
*/
#include <stdio.h>
#include <string.h>
int lcp(const char* a, const char* b){
    int i=0; while(a[i] && b[i] && a[i]==b[i]) i++; return i;
}
int main(void){
    char line[1024]; if(!fgets(line,sizeof(line),stdin)) return 0;
    char A=line[0]; char *rhs=strchr(line,'>'); if(!rhs) return 0; rhs++;
    char *p1=strtok(rhs,"|\n\r"); char *p2=strtok(NULL,"|\n\r");
    if(!p1||!p2){ puts("Need two alts"); return 0; }
    while(*p1==' ') p1++; while(*p2==' ') p2++;
    int k=lcp(p1,p2);
    if(k==0){ printf("%c->%s|%s\n",A,p1,p2); return 0; }
    printf("%c->%.*s%c'\n", A, k, p1, A);
    printf("%c'->%s|%s\n", A, p1+k, p2+k);
    return 0;
}
