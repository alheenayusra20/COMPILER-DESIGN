/*
Experiment 11: Demonstrate operator precedence (PEMDAS-like)
Input: 3+4*2
Output: 11
*/
#include <stdio.h>
#include <ctype.h>
const char* s; int i;
long parseE(); long parseT(); long parseF();
void skip(){ while(s[i]==' ') i++; }
long parseF(){ skip(); long v=0;
    if(s[i]=='('){ i++; v=parseE(); if(s[i]==')') i++; return v; }
    while(isdigit(s[i])){ v = v*10 + (s[i++]-'0'); }
    return v;
}
long parseT(){ long v=parseF(); skip();
    while(s[i]=='*'||s[i]=='/'){ char op=s[i++]; long r=parseF(); v = (op=='*')? v*r : v/r; skip(); }
    return v;
}
long parseE(){ long v=parseT(); skip();
    while(s[i]=='+'||s[i]=='-'){ char op=s[i++]; long r=parseT(); v = (op=='+')? v+r : v-r; skip(); }
    return v;
}
int main(void){
    static char buf[1024]; if(!fgets(buf,sizeof(buf),stdin)) return 0; s=buf; i=0;
    printf("%ld\n", parseE());
    return 0;
}
