/*
Experiment 12: Generate three-address code for an expression.
Input: a+b*c
Output:
t1 = b * c
t2 = a + t1
*/
#include <stdio.h>
#include <ctype.h>
const char* s; int i, tcnt=1;
void skip(){ while(s[i]==' ') i++; }
int isid(int c){ return (c>='a'&&c<='z')||(c>='A'&&c<='Z'); }
char parseF(){ skip(); char c=s[i++]; return c; }
char tmp(char* name){ sprintf(name,"t%d", tcnt++); return 0; }
void gen(const char* a,const char* op,const char* b,const char* res){ printf("%s = %s %s %s\n", res, a, op, b); }
void parseT(char out[]){
    char a=parseF(); skip();
    while(s[i]=='*'||s[i]=='/'){ char op=s[i++]; char b=parseF(); char t[8]; tmp(t); char A[2]={a,0}, B[2]={b,0}; gen(A, op=="*"? "*":"/", B, t); a='?'; strcpy(out,t); }
    if(a!='?'){ out[0]=a; out[1]=0; }
}
void parseE(){
    char left[16]; parseT(left); 
    while(s[i]=='+'||s[i]=='-'){
        char op=s[i++]; char right[16]; parseT(right);
        char t[8]; tmp(t); gen(left, op=="+"?"+":"-", right, t); strcpy(left,t);
    }
}
int main(void){
    static char buf[256]; if(!fgets(buf,sizeof(buf),stdin)) return 0; s=buf; i=0; parseE(); return 0;
}
